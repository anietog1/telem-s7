#include <mkl.h>
#include "distribution.h"

int diffusion(const int n_steps,
              const int n_particles,
              const float x_threshold,
              const float alpha,
              VSLStreamStatePtr rnStream) {
  float rn[n_particles][n_steps];
  vsRngUniform(VSL_RNG_METHOD_UNIFORM_STD, rnStream, n_particles * n_steps, (float*) rn, -1.0f, 1.0f);

  float x[n_particles];
  for(int i = 0; i < n_particles; ++i) {
    x[i] = 0.0f;
  }

  for (int i = 0; i < n_particles; i++) {
#pragma omp simd
    for (int j = 0; j < n_steps; j++) {
      x[i] += dist_func(alpha, rn[i][j]);
    }
  }

  int n_escaped = 0;
#pragma omp simd
  for(int i = 0; i < n_particles; ++i) {
    if(x[i] > x_threshold) {
      n_escaped++;
    }
  }

  return n_escaped;
}
